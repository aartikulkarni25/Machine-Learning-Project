
def scissors(observation, configuration):
    return 2
