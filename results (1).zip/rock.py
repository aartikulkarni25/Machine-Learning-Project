
def rock(observation, configuration):
    return 0
