
import random

def nash_equilibrium(observation, configuration):
    return random.randint(0, 2)
