
# Example of the simple agent
def your_agent(observation, configuration):
    return 0
