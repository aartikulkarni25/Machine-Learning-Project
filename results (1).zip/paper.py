
def paper(observation, configuration):
    return 1
